// Run this when the meteor app is started
Meteor.startup(function () {

    $(document).ready(function(){
    });


    someColor = '#404652';

});
