Template.layout.onRendered(function(){


});

